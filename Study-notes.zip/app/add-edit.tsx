import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  Alert,
  Platform
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';
import { getNoteById, addNote, updateNote, Note, NOTE_CATEGORIES } from '@/src/database/database';
import { scheduleStudyReminder } from '@/src/services/notificationService';
import { ThemedView } from '@/components/themed-view';
import { ThemedText } from '@/components/themed-text';

export default function AddEditNoteScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const isEditing = !!id;

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState(NOTE_CATEGORIES[0]);
  const [reminderTime, setReminderTime] = useState<Date | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);

  useEffect(() => {
    if (isEditing) {
      loadNote(Number(id));
    }
  }, [id]);

  const loadNote = async (noteId: number) => {
    const note = await getNoteById(noteId);
    if (note) {
      setTitle(note.title);
      setSubject(note.subject);
      setContent(note.content);
      if (note.category) setCategory(note.category);
      if (note.reminder_time) {
        setReminderTime(new Date(note.reminder_time));
      }
    }
  };

  const handleSave = async () => {
    if (!title.trim() || !content.trim()) {
      Alert.alert('Validation Error', 'Title and Content are required.');
      return;
    }

    const noteData: Omit<Note, 'id'> = {
      title,
      subject,
      content,
      category,
      created_at: new Date().toISOString(),
      reminder_time: reminderTime?.toISOString() || '',
    };

    try {
      if (isEditing) {
        await updateNote({ ...noteData, id: Number(id) });
      } else {
        await addNote(noteData);
      }

      if (reminderTime && reminderTime > new Date()) {
        await scheduleStudyReminder(title, reminderTime);
      }

      router.back();
    } catch (error: any) {
      console.error('Error saving note:', error);
      Alert.alert('Error', `Failed to save note: ${error.message || JSON.stringify(error)}`);
    }
  };

  const onDateChange = (event: any, selectedDate?: Date) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (selectedDate) {
      setReminderTime(selectedDate);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <ThemedView style={styles.form}>
        <ThemedText style={styles.label}>Title</ThemedText>
        <TextInput
          style={styles.input}
          placeholder="Enter note title"
          value={title}
          onChangeText={setTitle}
        />

        <ThemedText style={styles.label}>Subject</ThemedText>
        <TextInput
          style={styles.input}
          placeholder="e.g. Mathematics, History"
          value={subject}
          onChangeText={setSubject}
        />

        <ThemedText style={styles.label}>Category</ThemedText>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryContainer}>
          {NOTE_CATEGORIES.map(cat => (
            <TouchableOpacity 
              key={cat} 
              style={[styles.categoryChip, category === cat && styles.categoryChipActive]}
              onPress={() => setCategory(cat)}
            >
              <Text style={[styles.categoryChipText, category === cat && styles.categoryChipTextActive]}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <ThemedText style={styles.label}>Content</ThemedText>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Enter your notes here..."
          value={content}
          onChangeText={setContent}
          multiline
          numberOfLines={10}
          textAlignVertical="top"
        />

        {Platform.OS !== 'web' && (
          <>
            <TouchableOpacity 
              style={styles.reminderButton}
              onPress={() => setShowDatePicker(true)}
            >
              <Ionicons name="notifications-outline" size={20} color="#007AFF" />
              <Text style={styles.reminderButtonText}>
                {reminderTime 
                  ? `Reminder set for: ${reminderTime.toLocaleString()}` 
                  : 'Set Study Reminder'}
              </Text>
            </TouchableOpacity>

            {showDatePicker && (
              <DateTimePicker
                value={reminderTime || new Date()}
                mode="datetime"
                display="default"
                onChange={onDateChange}
                minimumDate={new Date()}
              />
            )}
          </>
        )}

        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Text style={styles.saveButtonText}>Save Note</Text>
        </TouchableOpacity>
      </ThemedView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  form: {
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    marginTop: 16,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#E5E5EA',
  },
  categoryContainer: {
    flexDirection: 'row',
    marginTop: 8,
  },
  categoryChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#E5E5EA',
    marginRight: 8,
    height: 36,
    justifyContent: 'center',
  },
  categoryChipActive: {
    backgroundColor: '#007AFF',
  },
  categoryChipText: {
    color: '#333',
    fontWeight: '500',
  },
  categoryChipTextActive: {
    color: '#FFF',
  },
  textArea: {
    height: 200,
    textAlignVertical: 'top',
  },
  reminderButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    padding: 12,
    backgroundColor: '#E5F1FF',
    borderRadius: 8,
  },
  reminderButtonText: {
    marginLeft: 8,
    color: '#007AFF',
    fontWeight: '600',
  },
  saveButton: {
    backgroundColor: '#007AFF',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 50,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
