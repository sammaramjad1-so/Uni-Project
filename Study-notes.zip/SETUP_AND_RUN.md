# Study Notes - Setup and Run Guide

Welcome to the **Study Notes** app! This guide covers everything you need to know to get the application running on your local machine and how to generate an `.apk` file for Android testing.

## Prerequisites

Before you begin, ensure you have the following installed on your system:
- **Node.js** (v18 or higher recommended)
- **npm** (comes with Node.js)
- **Git**
- *(Optional)* **Android Studio** (for Android Emulator) or **Xcode** (for iOS Simulator on Mac)

---

## 🚀 Setup & Run Process

### 1. Install Dependencies
Open a terminal in the root of your project directory (`/study-notes`) and install all required packages:

```bash
npm install
```

### 2. Start the Development Server
Once dependencies are installed, start the Expo Metro Bundler:

```bash
npm start
```
*(If you need to clear the cache, you can run `npm start -- --clear`)*

### 3. Run on Different Platforms
When the server starts, you will see a QR code and a list of commands in your terminal:
- **Web**: Press `w` to open the app in your local web browser.
- **Android**: Press `a` to open the app in an Android Emulator (requires Android Studio setup).
- **iOS**: Press `i` to open the app in the iOS Simulator (Mac only).
- **Physical Device**: Download the **Expo Go** app on your phone (from the App Store or Google Play) and scan the QR code displayed in your terminal.

---

## 📦 How to Generate an `.apk` File (Android)

To install the app directly onto an Android device without using Expo Go, you need an `.apk` file. We use **EAS (Expo Application Services)** to build the `.apk`.

### Step 1: Install EAS CLI
If you haven't already, install the EAS command-line tool globally:
```bash
npm install -g eas-cli
```

### Step 2: Log in to your Expo Account
```bash
eas login
```
*(If you don't have an account, create one at [expo.dev](https://expo.dev))*

### Step 3: Configure EAS for APK Builds
Ensure you have an `eas.json` file in the root of your project. If it doesn't exist, running `eas build:configure` will create one. 

To specifically generate an `.apk` (instead of an `.aab` for the Play Store), your `eas.json` should have a `preview` profile configured like this:

```json
{
  "build": {
    "preview": {
      "android": {
        "buildType": "apk"
      }
    },
    "production": {}
  }
}
```

### Step 4: Run the Android Build
Trigger the build process targeting your preview profile:

```bash
eas build -p android --profile preview
```

### Step 5: Download and Install
- The build process will run on Expo's cloud servers. 
- You can monitor the progress in your terminal or via the provided dashboard link.
- Once the build is successfully completed, the terminal will output a **download link** for your `.apk` file.
- Download the file to your Android device, allow installations from unknown sources in your settings, and install the app!
