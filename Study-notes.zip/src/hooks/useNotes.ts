import { useState, useEffect, useCallback } from 'react';
import { getNotes, addNote, updateNote, deleteNote, Note } from '../database/database';

export function useNotes() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotes = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getNotes();
      setNotes(data);
    } catch (error) {
      console.error('Error fetching notes:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchNotes();
  }, [fetchNotes]);

  const addNewNote = async (note: Omit<Note, 'id'>) => {
    const id = await addNote(note);
    await fetchNotes();
    return id;
  };

  const editNote = async (note: Note) => {
    await updateNote(note);
    await fetchNotes();
  };

  const removeNote = async (id: number) => {
    await deleteNote(id);
    await fetchNotes();
  };

  return {
    notes,
    loading,
    refreshNotes: fetchNotes,
    addNewNote,
    editNote,
    removeNote,
  };
}
