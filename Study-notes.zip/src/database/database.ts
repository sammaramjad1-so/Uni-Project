import * as SQLite from 'expo-sqlite';

export interface Note {
  id?: number;
  title: string;
  subject: string;
  content: string;
  created_at: string;
  reminder_time?: string;
  category?: string;
}

export const NOTE_CATEGORIES = ['Study', 'Work', 'Personal', 'Ideas', 'Finance', 'Other'];

const DATABASE_NAME = 'study_notes.db';

export async function initDatabase(dbInstance?: SQLite.SQLiteDatabase) {
  const db = dbInstance ?? await SQLite.openDatabaseAsync(DATABASE_NAME);
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      subject TEXT,
      content TEXT NOT NULL,
      created_at TEXT,
      reminder_time TEXT,
      category TEXT DEFAULT 'Uncategorized'
    );
  `);

  try {
    await db.execAsync(`ALTER TABLE notes ADD COLUMN category TEXT DEFAULT 'Uncategorized';`);
  } catch (error) {
    // Column already exists, ignore
  }
  return db;
}

export async function getNotes(): Promise<Note[]> {
  const db = await SQLite.openDatabaseAsync(DATABASE_NAME);
  const allRows = await db.getAllAsync<Note>('SELECT * FROM notes ORDER BY created_at DESC');
  return allRows;
}

export async function addNote(note: Omit<Note, 'id'>): Promise<number> {
  const db = await SQLite.openDatabaseAsync(DATABASE_NAME);
  const result = await db.runAsync(
    'INSERT INTO notes (title, subject, content, created_at, reminder_time, category) VALUES (?, ?, ?, ?, ?, ?)',
    [note.title, note.subject, note.content, note.created_at, note.reminder_time || '', note.category || 'Uncategorized']
  );
  return result.lastInsertRowId;
}

export async function updateNote(note: Note): Promise<void> {
  const db = await SQLite.openDatabaseAsync(DATABASE_NAME);
  await db.runAsync(
    'UPDATE notes SET title = ?, subject = ?, content = ?, reminder_time = ?, category = ? WHERE id = ?',
    [note.title, note.subject, note.content, note.reminder_time || '', note.category || 'Uncategorized', note.id!]
  );
}

export async function deleteNote(id: number): Promise<void> {
  const db = await SQLite.openDatabaseAsync(DATABASE_NAME);
  await db.runAsync('DELETE FROM notes WHERE id = ?', [id]);
}

export async function getNoteById(id: number): Promise<Note | null> {
  const db = await SQLite.openDatabaseAsync(DATABASE_NAME);
  const note = await db.getFirstAsync<Note>('SELECT * FROM notes WHERE id = ?', [id]);
  return note;
}
